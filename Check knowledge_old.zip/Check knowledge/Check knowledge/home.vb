﻿Imports System.IO

Public Class home

    Private Sub home_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Sub Main()
        ' We want to split this input string.
        Dim s As String = TextBox1.Text

        ' Split string based on spaces.
        Dim words As String() = s.Split(New Char() {" "c})

        ' Use For Each loop over words and display them.
        Dim word As String
        For Each word In words
            Console.WriteLine(word)
            '   Label1.Text = Label1.Text + 1
            ListBox1.Items.Add(word)
        Next
    End Sub
    Sub Main2()
        Dim i As Integer = 0

        ' Loop through each line in array returned by ReadAllLines.
        Dim line As String
        For Each line In File.ReadAllLines("data1.txt")

            ' Split line on comma.
            Dim parts As String() = line.Split(New Char() {","c})

            ' Loop over each string received.
            Dim part As String
            For Each part In parts
                ' Display to console.
                Console.WriteLine("{0}:{1}", i, part)
            Next
            i += 1
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Main()
        Label2.Text = Len(TextBox1.Text)
        Dim s As String = TextBox2.Text

        ' Split string based on spaces.
        Dim words As String() = s.Split(New Char() {" "c})

        ' Use For Each loop over words and display them.
        Dim word As String
        For Each word In words
            Console.WriteLine(word)
            'Label1.Text = Label1.Text + 1
            ListBox1.Items.Add(word)
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim i, j As Long
        For i = 0 To ListBox1.Items.Count - 1
            For j = ListBox1.Items.Count - 1 To (i + 1) Step -1
                If ListBox1.Items(i) = ListBox1.Items(j) Then
                    Label1.Text = Label1.Text + 1
                    ListBox1.Items.Remove(ListBox1.Items(j))

                End If
            Next
        Next
        MsgBox((Label1.Text * 100) / Label2.Text)
    End Sub
End Class